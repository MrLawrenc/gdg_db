package application.utils;

import java.time.LocalDateTime;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javafx.scene.control.TextArea;

/**
 * @Description 日志工具
 * @author Liu Mingyao
 * @date 2019年11月23日下午6:18:45
 */
public class LogUtil {
	private TextArea logText;
	private TextArea detailLog;

	public static final ThreadPoolExecutor BLOCK_QUEUE_EXECUTOR = new ThreadPoolExecutor(1, 1, 2, TimeUnit.SECONDS,
			new ArrayBlockingQueue<>(10000), Executors.defaultThreadFactory(), new ThreadPoolExecutor.AbortPolicy());

	public LogUtil(TextArea logText, TextArea detailLog) {
		super();
		BLOCK_QUEUE_EXECUTOR.prestartAllCoreThreads();
		this.logText = logText;
		this.detailLog = detailLog;
	}

	public void infoLog(Object str) {
		System.out.println(str);
		logText.appendText(LocalDateTime.now() + " " + str + "\n");
	}

	public void errorLog(Object str) {
		System.err.println(str);
		detailLog.appendText(LocalDateTime.now() + " error " + str + "\n");
	}

	public void detailLog(Object str) {
		detailLog.appendText(LocalDateTime.now() + " info " + str + "\n");
	}
}
